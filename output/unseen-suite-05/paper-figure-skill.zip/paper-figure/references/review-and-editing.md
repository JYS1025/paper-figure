# Review and preservation

## Two independent review passes

Content: compare required labels, nodes and directed relationships against the exported objects. Preserve training/inference scope, repeated-block meaning and parameter-sharing distinctions. Explicitly check what is absent as well as present. The contract is written from the brief, not inferred from the finished picture.

Appearance: render the saved PPTX, inspect each figure enlarged, then at its declared publication width. Check text clipping, manual breaks, padding, hierarchy, association of labels, intersections, arrow direction, contrast and available fonts. Inspect the whole figure after local changes. Structural checks cannot settle these questions. Stop after a small bounded number of rounds (usually three), preserving a record of remaining issues rather than claiming success by exhaustion.

For labeled review, check whether decision symbols and state encodings can be interpreted from the figure plus its intended adjacent caption. Standalone figures need their own essential definitions; do not duplicate a complete caption as a glossary. If a fill changes after an observation, verify that it denotes the stated classification/status rather than an unintended physical transformation. Review all essential statuses at the actual intended width and in grayscale, especially pale unmeasured/pending marks beside empty or negative marks. Record a failed contrast check as a local finishing issue when the underlying flow remains clear.

Use [relationship planning and review](relationship-review.md) for endpoint, set-scope, identity, expansion and matrix-axis checks. Run `scripts/flow_audit.py` on the saved file to locate suspicious anchors or unsupported geometry, then resolve its flags in the render. Valid object IDs can still connect to a transparent caption box far from the depicted data. The audit is read-only and its warnings are not automatic aesthetic failures.

Artifact Tool reimport, LibreOffice and PowerPoint are different renderers. If their output disagrees, inspect PowerPoint when available and record which renderer produced the preview. Do not call an Artifact Tool PNG a PowerPoint screenshot. Use only the bundled LibreOffice supplied by this environment. Pixel dimensions and physical preview dimensions must both be clear; browser print at 100% is more reliable for physical sizing than screen pixels alone.

## Inspect

```
python scripts/pptx.py inspect latest.pptx --contract contract.json --output inspect.json
```

Contracts have `slides:[{nodes:{name:exactText},edges:[[from,to]],groups:[name]}]`. Newlines in labels are significant. `exactEdges` and `nativeOnly` default to true. A contract checks only what it specifies; the author must add all scientifically essential content. Extra images can be allowed explicitly for inherently photographic inputs. Counts of native shapes alone do not prove their correctness.

## Local patch of the latest file

Save and close the user's current file or confirm it is not changing during the operation. Inspect **that file**, not an old manifest. A plan contains:

```json
{
  "sourceSha256":"<from latest inspection>",
  "operations":[{
    "slide":1,"id":"<current ID>","name":"encoder",
    "fingerprint":"<current object fingerprint>",
    "action":"replace_text","old":"Encoder","new":"Temporal encoder"
  }]
}
```

```
python scripts/pptx.py patch latest.pptx revised.pptx --plan edit.json --receipt receipt.json
```

The source hash prevents a stale edit; the current ID/name/fingerprint prevents an ambiguous target. Numeric IDs and names are not identities across arbitrary edits. If two objects have the same name after duplication, use the latest ID and visual context; never choose the first match. A failed precondition requires a fresh inspection, not disabling the check.

Supported text edits replace a unique substring in one text run, retaining that run's formatting. Cross-run replacement is rejected rather than flattening rich text. `move` uses CSS-pixel `dx`/`dy` for a top-level unrotated shape or unconnected group. Straight attached connectors are recomputed. Routed or connected-group moves require native PowerPoint. The patcher refuses to overwrite its source or an existing output.

`style_connector` changes only a native connector's stroke width, existing destination arrow size, cap and join. Supply `widthPx` (positive and at most 12), `arrowWidth` and `arrowLength` (`sm`, `med`, `lg`) in addition to the usual source/target preconditions. It retains direction, endpoints, geometry, color and dash. It refuses non-connectors and absent/non-directional destination arrows. Inspect and render the saved result; it does not repair routing or overlapping content.

All untouched ZIP-entry payloads remain byte-identical. Within an edited slide, review the changed XML objects and compare the preview; XML serialization may change prefixes, but unrelated subtree content must stay equivalent. Media, unknown package parts, comments and styles are preserved when they were not targeted. No import/export model round trip is used for these edits. Do not run the original generator after a person has changed the file.

Reinspect the patched file, render it, compare changed and unchanged regions, and open it in PowerPoint where possible. For an intentional content change update the relevant contract with the user's new requirement. A patch receipt is evidence of change scope, not a proof of visual quality.

# Image draft → editable figure

Use this optional route when the user requests an image-model draft, supplies a raster design to reconstruct, or a composition study would materially help the figure. Direct native authoring remains appropriate for simple diagrams and local edits. This route explores visual choices; it does not establish better quality by itself.

## Keep two sources of authority

The content contract is authoritative for labels, entities, direction, state, scope and scientific claims. The generated image is a visual reference for composition, proportions, hierarchy, spacing and meaningful device or representation cues. An attractive draft can still contain duplicated stages, impossible connections, misleading states or invented measurements.

Use the available image-generation skill/tool when generating a raster draft. Supply the same scientific brief, known/unknown quantities, intended publication width and a deliberate palette. Record the actual prompt and save the selected image in the task workspace. Do not force an image-generation dependency into tasks that do not need it; if the capability is unavailable, state that and continue with native authoring when it satisfies the request.

## Audit before rebuilding

View the draft before authoring. Trace required material/data paths and control paths against the contract. Check every named stage, repeated item, state distinction, legend, value and directional arrow. If a new shade or fill appears, decide whether it is cosmetic or encodes a real state. Do not silently create a third scientific category.

Before transferring its palette, test whether each essential status remains distinguishable at publication size and without hue. A pale draft state can collapse into an empty state after native reconstruction. Preserve the underlying identity and classification meaning, not merely the draft's RGB values; add symbol definitions or timing correspondence only as warranted by the brief and intended caption.

Record a short transfer plan:

- **Preserve:** composition, relative scale, density, spacing and visual devices that help explain the supplied method.
- **Correct:** semantic mistakes, unsupported details, inconsistent state encoding and misleading connections.
- **Adapt:** effects or geometry that need a native equivalent; explain any material loss of fidelity.

A corrected reconstruction need not copy every pixel. It should retain the draft's useful visual choices while satisfying the original brief. Do not replace the draft with the old generic layout and call that a faithful reconstruction.

## Reconstruct as native objects

Create text, modules, feature planes, tokens, channels and explanatory connectors as separate native objects. Use editable custom paths for appropriate contours. Use sensible groups for repeated structures. Match important proportions and negative space before detailing small marks.

Keep the full raster draft out of the delivered editable diagram. Do not hide it beneath labels, package it as one picture/SVG, or auto-trace thousands of tiny shapes and claim useful editability. A genuine photographic input may remain a picture where the task calls for it; generated imagery is not experimental evidence.

Native gradients or other supported fills may preserve useful appearance, but cannot substitute for state definitions. Inspect how they render from the saved PPTX; a simpler faithful fill is preferable to a malformed effect. Bind semantic connectors to visible objects as described in [authoring](authoring.md), not to a tracing image or a distant caption.

## Verify both meaning and visual transfer

Use the ordinary contract, saved-file render and relationship checks. Separately compare draft and reconstruction at equal intended publication widths: composition, relative sizes, line hierarchy, clearances, palette allocation and typography. Inspect native object/media counts to catch an accidentally flattened reconstruction. XML checks support editability claims but do not replace an interactive application test.

Record which useful visual decisions survived, what was deliberately corrected, and any remaining fidelity loss. Preserve the draft, final editable figure, rendered preview and concise evidence. Avoid claiming the image-first route wins merely because the draft looks more elaborate.

When the user requests a comparison, distinguish three questions: whether the raster draft is visually effective; whether the PPTX retains that effectiveness while correcting its content; and whether the resulting PPTX improves on direct native generation. Follow [blind review](blind-review.md) with neutral wording appropriate to the actual classes. Do not tell a reviewer that one image is published when comparing two generated candidates. Keep a common brief and size, hide workflow identities, and disclose unequal prompts, review budgets or prior feedback that limit causal conclusions.

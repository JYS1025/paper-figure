---
name: paper-figure
description: Create or revise editable PowerPoint figures for research papers—model architectures, methodology, process and conceptual diagrams. Use when labels, modules and arrows must remain individually editable. Excludes statistical plotting and ordinary presentation decks.
---

# Paper figures in PowerPoint

Produce PPTX, a preview rendered from that PPTX, and a short validation note. Keep text, diagram shapes, cells and connectors native. Images are appropriate for inherently photographic inputs; do not flatten the diagram to an image or one SVG. Use PowerPoint as the editor.

## Choose the work target

For a figure request, create or revise the requested artifact. For a skill-improvement request, including evaluation feedback supplied during skill development, update the reusable instructions and checks; do not substitute editing example figures for improving the skill. For a review-only request, report observations without changing the artifact. Use the ongoing task's scope to interpret pasted feedback.

## Create

1. Extract required labels, nodes, directed edges, hierarchy, repetition and training/inference distinctions into a content contract **before drawing**. Add a compact private relationship plan using [relationship planning and review](references/relationship-review.md): what each mark represents, whether an edge carries one item or a set, visible endpoints, identity across views, and any unspecified operation. Preserve supplied content; do not fill semantic gaps with invented mechanisms.
2. Choose the paper's intended width and aspect ratio. If unspecified, state a provisional width. Open and visually inspect relevant original figures from [reference cards](references/reference-cards.md) or the user's references. Identify the relationship each visual device explains and whether it applies to this method. Familiarity, complexity, photographs and thick arrows are not quality criteria by themselves.
3. Choose representations using [visual design](references/visual-design.md). Show meaningful inputs, state changes, spatial structure or a worked relationship where the method needs them. Trace the main path, a branch/merge and one recurring item before styling. Resolve gaps in endpoints, collection scope or axis correspondence before adjusting line weight. Choose a compatible [color book](references/color-books.md), or preserve the manuscript's established palette; record its semantic role mapping and use its fill/stroke/accent levels deliberately. Pastel is not an AI-authorship cue. Keep a simple overview when it adequately serves its purpose; do not add panels or decoration to make it harder to classify as generated.
4. When the user requests an image-model draft, supplies a raster design, or composition exploration would materially help, use the optional [image-first workflow](references/image-first.md): audit the draft against the content contract, then preserve its useful visual choices in native PPT objects. Otherwise author directly. Use [authoring](references/authoring.md) and `scripts/figure.mjs` with the bundled Artifact Tool runtime. Read the environment's Presentations implementation/finalization instructions when available. See `examples/build-rich-examples.mjs` for diverse representations; `build-examples.mjs` is only a structural baseline. Adapt the design to the actual method instead of recycling these compositions. Independent content contracts are in `examples/tasks.json`.
5. Inspect the **exported** PPTX with `scripts/pptx.py inspect --contract` and `scripts/flow_audit.py`. A missing/reversed required edge is a semantic failure. The flow audit flags transparent anchors, unsupported geometry and coordinate gaps for rendered review; it does not decide visual quality. Render at full size and intended publication width and run the applicable checks in [relationship review](references/relationship-review.md). Verify symbol/state definitions against the intended caption and essential state distinctions in reduced grayscale; add timing correspondence only when the supplied method needs it. Follow [review and editing](references/review-and-editing.md) for preservation.
6. Classify findings as structural defects, conditional explanation improvements or finishing changes. Repair confirmed defects first and preserve successful regions. Do not force a fixed number of criticisms or add unspecified operators to satisfy a reviewer. Usually stop within three review rounds and state unresolved limitations. Never claim an app edit test based on XML or a preview.

## Revise a user's PPTX

Use the latest saved PPTX. Inspect current objects and compare with the requested edit. Names and IDs can change after duplication, deletion or saving; combine slide, current ID, name, text, fingerprint and source hash. `scripts/pptx.py patch` supports conservative text replacement and simple translations, writing a new file. Read [review and editing](references/review-and-editing.md) for limits and preservation checks. Use native PowerPoint for operations outside those limits. Do not regenerate from old source code over human edits.

## Scope of assurance

Simple formula labels use editable Unicode text, not a full Office equation editor. Use an actual equation object only when the authoring environment supports and validates it; do not claim that the simple labels are OMML. Groups and connectors require saved-file verification. Routed connectors can render differently across engines; use the bundled LibreOffice or PowerPoint to cross-check. Do not re-export a human-edited file through Artifact Tool solely to render it.

Keep structural, visual, native-app and model-comparison results separate. See [evaluation](references/evaluation.md) for the eight tasks and four-condition protocol. Do not synthesize a comparison result by labeling handcrafted examples as independent model runs.

When a blind comparison or verifier is requested, use [blind review](references/blind-review.md). Keep the answer key out of the evaluator context, record recognition from memory, and separate source classification from visual quality. This diagnostic is conditional, not a mandatory extra model call for every figure.

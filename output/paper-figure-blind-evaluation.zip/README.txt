Attach the four comparison PNGs and evaluator-prompt.md to a fresh model context. Do not provide source files or prior conversation. The PDF contains the same masked pages. No answer key is included.
